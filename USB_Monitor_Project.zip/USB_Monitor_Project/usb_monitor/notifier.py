from plyer import notification
import sys
import tkinter as tk # 导入 tkinter
from tkinter import messagebox # 导入 messagebox

def notify_user(title, message, app_name="USB 监控器"):
    """
    通过桌面通知或弹窗提示用户。
    参数:
        title (str): 通知或弹窗的标题。
        message (str): 通知或弹窗的内容。
        app_name (str): 发送通知的应用程序名称。
    """
    try:
        # 尝试使用 plyer 发送桌面通知
        notification.notify(
            title=title,
            message=message,
            app_name=app_name,
            timeout=10 # 通知显示时间，单位秒
        )
    except Exception as e:
        # 如果 plyer 失败或未安装，尝试使用 tkinter.messagebox 作为备用方案
        print(f"无法发送桌面通知: {e}. 尝试使用备用弹窗 (如果可用)。")
        try:
            # 创建一个 Tkinter 根窗口实例，但不显示它
            root = tk.Tk()
            root.withdraw() # 隐藏主窗口，只显示消息框

            # 显示一个信息弹窗
            messagebox.showinfo(title, message)
            root.destroy() # 销毁 Tkinter 根窗口

        except ImportError:
            # 如果 tkinter 都未安装或无法导入
            print(f"警告: 无法使用 tkinter.messagebox，请检查是否在 GUI 环境下运行或安装 tkinter。")
            print(f"通知: {title} - {message}") # 仅在控制台打印消息
        except Exception as e_tk:
            # 捕获 tkinter 使用过程中可能发生的其他异常
            print(f"使用 tkinter.messagebox 失败: {e_tk}")
            print(f"通知: {title} - {message}") # 仅在控制台打印消息
