# 黑名单文件扩展名列表
# 扫描器会查找这些扩展名的文件，并将其标记为高风险。
# 这些是常见的可执行文件、脚本文件和可能包含恶意代码的文件扩展名。
BLACKLISTED_EXTENSIONS = [
    '.exe',     # Windows 可执行文件
    '.bat',     # Windows 批处理文件
    '.cmd',     # Windows 命令脚本
    '.vbs',     # VBScript 脚本文件
    '.js',      # JavaScript 文件 (在某些上下文可执行)
    '.ps1',     # PowerShell 脚本文件
    '.scr',     # 屏幕保护程序文件 (可执行)
    '.lnk',     # Windows 快捷方式文件 (可被恶意利用执行命令)
    '.com',     # DOS 应用程序
    '.pif',     # 程序信息文件 (可执行)
    '.sh',      # Linux/Unix shell 脚本
    '.reg',     # 注册表文件 (可修改系统设置)
    '.dll'      # 动态链接库 (可被劫持或加载恶意代码)
]

# 可疑文件名列表
# 扫描器会查找这些精确文件名的文件，即使它们的扩展名不在黑名单中。
# 这些文件名通常被恶意软件用来伪装成系统文件或常见程序。
SUSPICIOUS_FILES = [
    'autorun.inf',      # 自动运行配置文件，尽管现代 Windows 已禁用其自动执行，但仍是感染迹象
    'svchost.exe',      # 恶意软件常用伪装名 (真实 svchost.exe 在 System32 目录下)
    'explorer.exe',     # 恶意软件常用伪装名
    'csrss.exe',        # 恶意软件常用伪装名
    'lsass.exe',        # 恶意软件常用伪装名
    'smss.exe',         # 恶意软件常用伪装名
    'winlogon.exe',     # 恶意软件常用伪装名
    'update.exe',       # 常见的恶意更新程序名
    'install.exe',      # 常见的恶意安装程序名
    'setup.exe',        # 常见的恶意安装程序名
    'README.txt.exe',   # 勒索软件常用伪装 (txt 扩展名在实际执行时被 .exe 覆盖)
    'HOWTO_DECRYPT.txt',# 勒索软件常用文件 (通常包含解密说明)
    # 可以根据需要添加更多可疑文件名，例如常见的勒索软件或恶意软件的文件名
]

# 其他未来可能用到的配置项 (目前未在代码中直接使用，但可以在此扩展)
# LOG_FILE_PATH = 'usb_monitor.log' # 日志文件路径
# NOTIFICATION_TIMEOUT_SECONDS = 10 # 通知显示时间（秒）
