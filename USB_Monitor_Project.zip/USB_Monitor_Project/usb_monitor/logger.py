# usb_monitor/logger.py
import logging
import os
import sys # 导入 sys 模块以使用 sys.stdout

def setup_logging(log_file='usb_monitor.log'):
    """
    配置日志记录。
    参数:
        log_file (str): 日志文件的路径。
    返回:
        logging.Logger: 配置好的日志记录器实例。
    """
    # 确保日志文件目录存在
    # 如果 log_file 是 "usb_monitor.log"，则 log_dir 会是空字符串，os.path.exists("") 为 True
    # 如果 log_file 是 "logs/usb_monitor.log"，则 log_dir 会是 "logs"，需要创建
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # 配置基本的日志设置
    logging.basicConfig(
        level=logging.INFO, # 设置全局日志级别为 INFO，这意味着 INFO, WARNING, ERROR, CRITICAL 级别的日志都会被处理
        format='%(asctime)s - %(levelname)s - %(message)s', # 定义日志消息的格式
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'), # 将日志输出到指定的文件，并使用 UTF-8 编码
            logging.StreamHandler(sys.stdout) # 同时将日志输出到标准输出 (控制台)
        ]
    )
    # 禁用 plyer 内部的日志输出到控制台，避免其自身的调试信息干扰
    logging.getLogger('plyer').setLevel(logging.WARNING)
    # 禁用 pywin32 相关的 COM 和 WMI 模块的日志，减少不必要的输出
    logging.getLogger('com').setLevel(logging.WARNING)
    logging.getLogger('WMI').setLevel(logging.WARNING)

    # 获取一个特定名称的日志记录器实例，通常推荐使用 __name__
    logger = logging.getLogger(__name__)
    return logger
