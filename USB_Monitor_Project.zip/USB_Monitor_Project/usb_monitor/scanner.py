import os
from usb_monitor.notifier import notify_user

def scan_drive(drive_path, logger, blacklisted_extensions, suspicious_files):
    """
    扫描指定驱动器路径是否存在 autorun.inf 或其他风险文件。
    参数:
        drive_path (str): 要扫描的驱动器或挂载点的路径。
        logger (logging.Logger): 日志记录器实例。
        blacklisted_extensions (list): 黑名单文件扩展名列表。
        suspicious_files (list): 可疑文件名列表。
    """
    logger.info(f"正在扫描驱动器: {drive_path}")
    found_risks = [] # 存储发现的风险文件信息

    # 检查 autorun.inf 文件
    autorun_path = os.path.join(drive_path, 'autorun.inf')
    if os.path.exists(autorun_path):
        found_risks.append(f"发现 autorun.inf 文件: {autorun_path}")
        logger.warning(f"风险警告: 发现 autorun.inf 文件在 {drive_path}")
        notify_user("风险文件警告", f"在 {drive_path} 发现 autorun.inf 文件。")

    # 扫描根目录下的可疑文件
    try:
        # 遍历驱动器根目录下的所有文件和子目录
        for item in os.listdir(drive_path):
            item_path = os.path.join(drive_path, item)
            # 只处理文件，跳过目录
            if os.path.isfile(item_path):
                # 检查文件名是否在可疑文件列表中 (不区分大小写)
                if item.lower() in [f.lower() for f in suspicious_files]:
                    found_risks.append(f"发现可疑文件: {item_path}")
                    logger.warning(f"风险警告: 发现可疑文件 '{item}' 在 {drive_path}")
                    notify_user("风险文件警告", f"在 {drive_path} 发现可疑文件: {item}")

                # 检查文件扩展名是否在黑名单中 (不区分大小写)
                _, ext = os.path.splitext(item) # 分离文件名和扩展名
                if ext.lower() in blacklisted_extensions:
                    found_risks.append(f"发现高风险文件 (黑名单扩展名): {item_path}")
                    logger.warning(f"风险警告: 发现黑名单扩展名文件 '{item}' 在 {drive_path}")
                    notify_user("高风险文件警告", f"在 {drive_path} 发现高风险文件 (黑名单扩展名): {item}")
    except PermissionError:
        # 如果没有权限访问驱动器，记录错误并通知用户
        logger.error(f"没有权限访问驱动器 {drive_path} 的文件。请以管理员权限运行。")
        notify_user("权限错误", f"没有权限访问驱动器 {drive_path} 的文件。")
    except Exception as e:
        # 捕获其他扫描过程中可能发生的异常
        logger.error(f"扫描驱动器 {drive_path} 时发生错误: {e}", exc_info=True)

    # 根据是否发现风险文件给出最终扫描结果的通知
    if not found_risks:
        logger.info(f"驱动器 {drive_path} 扫描完成，未发现明显风险文件。")
        notify_user("扫描完成", f"驱动器 {drive_path} 扫描完成，未发现明显风险。")
    else:
        logger.info(f"驱动器 {drive_path} 扫描完成，发现 {len(found_risks)} 处风险。")

