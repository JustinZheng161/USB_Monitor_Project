# usb_monitor/monitor.py - 此文件已更新
import sys
import threading
import platform
import time
import os

from usb_monitor.scanner import scan_drive
from usb_monitor.notifier import notify_user

class USBMonitor:
    """
    USB 监控器，负责检测 USB 设备的插入和移除。
    根据操作系统调用不同的底层检测方法。
    """
    def __init__(self, logger, blacklisted_extensions, suspicious_files):
        self.logger = logger
        self.blacklisted_extensions = blacklisted_extensions
        self.suspicious_files = suspicious_files
        self._running = False # 监控器运行状态标志
        self._os_type = platform.system() # 获取当前操作系统类型 (如 'Windows', 'Linux')
        self._observer = None # 用于存储 Linux pyudev 或 Windows WMI 的观察者/查询对象

        self.logger.info(f"初始化 USBMonitor, 操作系统: {self._os_type}")

    def _on_device_added(self, device_info):
        """
        处理 USB 设备插入事件。
        参数:
            device_info (dict): 包含设备名称 ('name') 和路径 ('path') 的字典。
        """
        name = device_info.get('name', '未知设备')
        path = device_info.get('path')
        self.logger.info(f"检测到 USB 设备插入: 名称='{name}', 路径='{path}'")
        # 通过 notifier 模块发送桌面通知
        notify_user("USB 设备插入", f"检测到 USB 设备插入: {name} ({path})")

        if path and os.path.exists(path):
            self.logger.info(f"开始扫描设备: {path}")
            # 在单独的线程中扫描驱动器，避免阻塞主监控线程
            scan_thread = threading.Thread(
                target=scan_drive,
                args=(path, self.logger, self.blacklisted_extensions, self.suspicious_files)
            )
            scan_thread.start()
        else:
            self.logger.warning(f"无法访问新插入设备的路径: {path}")

    def _on_device_removed(self, device_info):
        """
        处理 USB 设备移除事件。
        参数:
            device_info (dict): 包含设备名称 ('name') 和路径 ('path') 的字典。
        """
        name = device_info.get('name', '未知设备')
        path = device_info.get('path')
        self.logger.info(f"检测到 USB 设备移除: 名称='{name}', 路径='{path}'")
        # 通过 notifier 模块发送桌面通知
        notify_user("USB 设备移除", f"USB 设备已移除: {name} ({path})")

    def _windows_monitor(self):
        """
        Windows 平台 USB 监控实现 (使用 WMI)。
        """
        try:
            # 尝试导入 pywin32 库所需的模块
            import win32com.client
            import pythoncom
        except ImportError:
            self.logger.error("在 Windows 上运行需要 'pywin32' 库。请运行 'pip install pywin32'。")
            notify_user("错误", "缺少 pywin32 库，无法在 Windows 上监控 USB。")
            return

        self.logger.info("启动 Windows WMI 监控...")
        # 获取 WMI 服务对象
        wmi = win32com.client.GetObject("winmgmts:")
        # 订阅 USB 卷创建事件（设备插入）
        raw_wmi_add = wmi.ExecNotificationQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_Volume'")
        # 订阅 USB 卷删除事件（设备移除）
        raw_wmi_remove = wmi.ExecNotificationQuery("SELECT * FROM __InstanceDeletionEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_Volume'")

        self.logger.info("WMI 订阅成功。")
        # 定义一个短的超时时间（毫秒），以便循环能响应 _running 标志
        timeout_ms = 500 # 500 毫秒

        # 预期的 COM 错误 HRESULT，表示超时，不应作为错误报告
        # -2147352567 (0x80020009) 是 DISP_E_EXCEPTION，常见于 NextEvent 超时
        # -2147217399 (0x80041009) 是 WBEM_E_TIMED_OUT
        # -2147209215 (0x80042001) 是 WBEM_S_TIMEDOUT (Success with warning)
        EXPECTED_COM_TIMEOUT_HRESULTS = [-2147352567, -2147217399, -2147209215]


        while self._running:
            try:
                # 轮询添加事件
                try:
                    added_event = raw_wmi_add.NextEvent(timeout_ms) # 使用 NextEvent() 轮询事件
                    target_instance = added_event.TargetInstance
                    # DriveLetter 存在且 DriveType 为 2 (可移动磁盘)
                    if target_instance.DriveLetter and target_instance.DriveType == 2:
                        drive_letter = target_instance.DriveLetter
                        label = target_instance.Label or "无标签"
                        self._on_device_added({'name': label, 'path': f"{drive_letter}\\"})
                except pythoncom.com_error as e:
                    # 忽略预期的 COM 超时错误
                    if e.hresult in EXPECTED_COM_TIMEOUT_HRESULTS:
                        pass # 预期超时，不记录错误
                    else:
                        raise # 如果不是预期超时错误，则重新抛出

                # 轮询移除事件
                try:
                    removed_event = raw_wmi_remove.NextEvent(timeout_ms) # 使用 NextEvent() 轮询事件
                    target_instance = removed_event.TargetInstance
                    if target_instance.DriveLetter and target_instance.DriveType == 2:
                        drive_letter = target_instance.DriveLetter
                        label = target_instance.Label or "无标签"
                        self._on_device_removed({'name': label, 'path': f"{drive_letter}\\"})
                except pythoncom.com_error as e:
                    # 忽略预期的 COM 超时错误
                    if e.hresult in EXPECTED_COM_TIMEOUT_HRESULTS:
                        pass # 预期超时，不记录错误
                    else:
                        raise # 如果不是预期超时错误，则重新抛出
                
                # 处理 COM 消息，非常重要，否则事件不会被处理
                pythoncom.PumpWaitingMessages()
                # NextEvent 已经提供了超时，所以这里不需要额外的 time.sleep
            except pythoncom.com_error as e:
                # 忽略预期的 COM_E_NOT_REGISTERED 错误，这可能发生在关闭时
                if e.hresult == -2147221164: # COM_E_NOT_REGISTERED
                    self.logger.info("WMI 监控 COM 对象已注销，正常退出。")
                    break
                # 如果是其他非预期的 COM 错误，则记录
                self.logger.error(f"WMI 监控发生非预期 COM 错误: {e}", exc_info=True)
            except Exception as e:
                # 捕获其他非 COM 异常并记录
                self.logger.error(f"WMI 监控发生未知错误: {e}", exc_info=True)
                break # 发生意外错误时退出循环

    def _linux_monitor(self):
        """
        Linux 平台 USB 监控实现 (使用 pyudev)。
        """
        try:
            # 尝试导入 pyudev 和 psutil 库
            import pyudev
            import psutil
        except ImportError:
            self.logger.error("在 Linux 上运行需要 'pyudev' 和 'psutil' 库。请运行 'pip install pyudev psutil'。")
            notify_user("错误", "缺少 pyudev/psutil 库，无法在 Linux 上监控 USB。")
            return

        self.logger.info("启动 Linux pyudev 监控...")
        context = pyudev.Context() # 创建 udev 上下文
        monitor = pyudev.Monitor.from_netlink(context) # 从内核 netlink 创建监控器
        monitor.filter_by(subsystem='block') # 过滤只监听块设备事件

        self._observer = pyudev.MonitorObserver(monitor) # 创建监控观察者
        self._observer.start() # 启动观察者线程

        def device_event(action, device):
            """
            处理 udev 设备事件的回调函数。
            参数:
                action (str): 事件类型，如 'add', 'remove'。
                device (pyudev.Device): 触发事件的设备对象。
            """
            if not self._running: # 检查运行状态，允许优雅退出
                return

            # 检查设备是否是 USB 总线上的设备
            if 'ID_BUS' in device and device['ID_BUS'] == 'usb':
                dev_node = device.device_node # 设备节点，例如: /dev/sdb1
                # 尝试获取文件系统标签或设备型号作为设备名称，否则使用设备节点的基本名称
                device_name = device.get('ID_FS_LABEL') or device.get('ID_MODEL') or os.path.basename(dev_node)

                mount_path = None
                # 使用 psutil 遍历所有磁盘分区，查找设备的挂载点
                for part in psutil.disk_partitions():
                    if part.device == dev_node:
                        mount_path = part.mountpoint
                        break

                if action == 'add':
                    # 如果找到了挂载点，则使用挂载点；否则使用设备节点
                    self._on_device_added({'name': device_name, 'path': mount_path or dev_node})
                elif action == 'remove':
                    self._on_device_removed({'name': device_name, 'path': mount_path or dev_node})
            elif action == 'add' and 'DEVTYPE' in device and device['DEVTYPE'] == 'partition':
                 # 对于某些系统，ID_BUS 可能不直接用于分区，因此提供一个回退机制
                 # 检查是否是新的分区设备
                dev_node = device.device_node
                device_name = device.get('ID_FS_LABEL') or os.path.basename(dev_node)
                mount_path = None
                for part in psutil.disk_partitions():
                    if part.device == dev_node:
                        mount_path = part.mountpoint
                        break
                # 只有当找到挂载路径时，才认为它是一个可用的 USB 驱动器
                if mount_path:
                    self._on_device_added({'name': device_name, 'path': mount_path})

        self._observer.connect(device_event) # 将回调函数连接到观察者
        self.logger.info("pyudev 订阅成功。")

        # 保持此线程运行，直到 stop_monitoring 被调用
        while self._running:
            time.sleep(1)


    def start_monitoring(self):
        """
        启动 USB 监控。
        """
        self._running = True
        self.logger.info("开始 USB 监控...")
        if self._os_type == "Windows":
            self._windows_monitor()
        elif self._os_type == "Linux":
            self._linux_monitor()
        else:
            # 如果是其他不支持的操作系统，则记录错误并通知用户
            self.logger.error(f"不支持的操作系统: {self._os_type}")
            notify_user("错误", f"不支持当前操作系统: {self._os_type}")

    def stop_monitoring(self):
        """
        停止 USB 监控。
        """
        self.logger.info("停止 USB 监控...")
        self._running = False # 设置运行标志为 False
        if self._os_type == "Linux" and self._observer:
            self._observer.stop() # 停止 pyudev 观察者
            self._observer.join() # 等待观察者线程完全结束
        # Windows WMI 监控会在 _running 设为 False 后自然退出循环
        self.logger.info("USB 监控停止完成。")
