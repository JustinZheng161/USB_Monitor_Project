# run.py
import sys
import threading
import time
import os
import ctypes

# 导入 usb_monitor 包中的各个模块
from usb_monitor.monitor import USBMonitor
from usb_monitor.logger import setup_logging
from usb_monitor.config import BLACKLISTED_EXTENSIONS, SUSPICIOUS_FILES

def main():
    """
    程序入口，设置日志并启动 USB 监控。
    """
    print("USB 插入行为监控器启动中...")

    # 设置日志
    # 日志文件将保存在程序运行目录下的 usb_monitor.log
    log_file_path = "usb_monitor.log"
    logger = setup_logging(log_file_path)

    # 检查是否以管理员权限运行 (仅限 Windows 平台)
    if sys.platform == "win32":
        try:
            # os.getuid() 仅存在于 Unix-like 系统，Windows 上会抛出 AttributeError
            is_admin = (os.getuid() == 0)
        except AttributeError:
            # 在 Windows 上使用 ctypes.windll.shell32.IsUserAnAdmin() 检查管理员权限
            is_admin = (ctypes.windll.shell32.IsUserAnAdmin() != 0)

        if not is_admin:
            logger.warning("请以管理员权限运行本程序，否则可能无法正确检测 USB 设备或访问驱动器。")
            print("警告: 请以管理员权限运行本程序，否则可能无法正确检测 USB 设备或访问驱动器。")

    # 初始化 USBMonitor 类，传入日志器和配置文件中的黑名单/可疑文件列表
    monitor = USBMonitor(logger, BLACKLISTED_EXTENSIONS, SUSPICIOUS_FILES)

    # 在单独的线程中运行监控器，避免阻塞主线程
    # daemon=True 表示当主线程退出时，这个子线程也会随之退出
    monitor_thread = threading.Thread(target=monitor.start_monitoring, daemon=True)
    monitor_thread.start()

    logger.info("USB 监控器已启动。按 Ctrl+C 退出。")
    # 添加提示，说明监控器正在等待事件
    logger.info("监控器正在等待 USB 设备插入或移除事件...")
    print("USB 监控器已启动。按 Ctrl+C 退出。")
    print("监控器正在等待 USB 设备插入或移除事件...")

    try:
        # 主线程持续休眠，保持程序运行，直到用户按下 Ctrl+C
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        # 捕获 Ctrl+C 中断信号，优雅地关闭监控器
        logger.info("用户请求退出，USB 监控器正在关闭。")
        print("用户请求退出，USB 监控器正在关闭。")
    finally:
        # 确保在程序退出前停止监控器
        monitor.stop_monitoring()
        logger.info("USB 监控器已关闭。")
        print("USB 监控器已关闭。")

if __name__ == "__main__":
    # 在运行 main 函数之前，确保 usb_monitor 目录存在
    # 这是为了在 logger.py 中创建日志文件时，目录结构是正确的
    if not os.path.exists("usb_monitor"):
        os.makedirs("usb_monitor")

    main()


# usb_monitor/monitor.py
import sys
import threading
import platform
import time
import os

from usb_monitor.scanner import scan_drive
from usb_monitor.notifier import notify_user

class USBMonitor:
    """
    USB 监控器，负责检测 USB 设备的插入和移除。
    根据操作系统调用不同的底层检测方法。
    """
    def __init__(self, logger, blacklisted_extensions, suspicious_files):
        self.logger = logger
        self.blacklisted_extensions = blacklisted_extensions
        self.suspicious_files = suspicious_files
        self._running = False # 监控器运行状态标志
        self._os_type = platform.system() # 获取当前操作系统类型 (如 'Windows', 'Linux')
        self._observer = None # 用于存储 Linux pyudev 或 Windows WMI 的观察者/查询对象

        self.logger.info(f"初始化 USBMonitor, 操作系统: {self._os_type}")

    def _on_device_added(self, device_info):
        """
        处理 USB 设备插入事件。
        参数:
            device_info (dict): 包含设备名称 ('name') 和路径 ('path') 的字典。
        """
        name = device_info.get('name', '未知设备')
        path = device_info.get('path')
        self.logger.info(f"检测到 USB 设备插入: 名称='{name}', 路径='{path}'")
        # 通过 notifier 模块发送桌面通知
        notify_user("USB 设备插入", f"检测到 USB 设备插入: {name} ({path})")

        if path and os.path.exists(path):
            self.logger.info(f"开始扫描设备: {path}")
            # 在单独的线程中扫描驱动器，避免阻塞主监控线程
            scan_thread = threading.Thread(
                target=scan_drive,
                args=(path, self.logger, self.blacklisted_extensions, self.suspicious_files)
            )
            scan_thread.start()
        else:
            self.logger.warning(f"无法访问新插入设备的路径: {path}")

    def _on_device_removed(self, device_info):
        """
        处理 USB 设备移除事件。
        参数:
            device_info (dict): 包含设备名称 ('name') 和路径 ('path') 的字典。
        """
        name = device_info.get('name', '未知设备')
        path = device_info.get('path')
        self.logger.info(f"检测到 USB 设备移除: 名称='{name}', 路径='{path}'")
        # 通过 notifier 模块发送桌面通知
        notify_user("USB 设备移除", f"USB 设备已移除: {name} ({path})")

    def _windows_monitor(self):
        """
        Windows 平台 USB 监控实现 (使用 WMI)。
        """
        try:
            # 尝试导入 pywin32 库所需的模块
            import win32com.client
            import pythoncom
        except ImportError:
            self.logger.error("在 Windows 上运行需要 'pywin32' 库。请运行 'pip install pywin32'。")
            notify_user("错误", "缺少 pywin32 库，无法在 Windows 上监控 USB。")
            return

        self.logger.info("启动 Windows WMI 监控...")
        # 获取 WMI 服务对象
        wmi = win32com.client.GetObject("winmgmts:")
        # 订阅 USB 卷创建事件（设备插入）
        raw_wmi_add = wmi.ExecNotificationQuery("SELECT * FROM __InstanceCreationEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_Volume'")
        # 订阅 USB 卷删除事件（设备移除）
        raw_wmi_remove = wmi.ExecNotificationQuery("SELECT * FROM __InstanceDeletionEvent WITHIN 2 WHERE TargetInstance ISA 'Win32_Volume'")

        self.logger.info("WMI 订阅成功。")
        while self._running:
            try:
                # 尝试获取新插入的卷事件
                # ExecNotificationQuery 返回一个 COM 对象，可以像迭代器一样使用
                for instance in raw_wmi_add:
                    if not self._running: # 检查运行状态，允许优雅退出
                        break
                    target_instance = instance.TargetInstance # 获取事件的目标实例
                    # DriveLetter 存在且 DriveType 为 2 (可移动磁盘)
                    if target_instance.DriveLetter and target_instance.DriveType == 2:
                        drive_letter = target_instance.DriveLetter
                        label = target_instance.Label or "无标签" # 获取卷标，如果为空则设为“无标签”
                        self._on_device_added({'name': label, 'path': f"{drive_letter}\\"})
                
                # 尝试获取被移除的卷事件
                for instance in raw_wmi_remove:
                    if not self._running: # 检查运行状态，允许优雅退出
                        break
                    target_instance = instance.TargetInstance
                    if target_instance.DriveLetter and target_instance.DriveType == 2:
                        drive_letter = target_instance.DriveLetter
                        label = target_instance.Label or "无标签"
                        self._on_device_removed({'name': label, 'path': f"{drive_letter}\\"})
                
                # 处理 COM 消息，非常重要，否则事件不会被处理
                pythoncom.PumpWaitingMessages()
                time.sleep(0.5) # 短暂休眠以避免过度占用 CPU 资源
            except pythoncom.com_error as e:
                # 忽略预期的 COM_E_NOT_REGISTERED 错误，这可能发生在关闭时
                if e.hresult == -2147221164: # COM_E_NOT_REGISTERED
                    self.logger.info("WMI 监控 COM 对象已注销，正常退出。")
                    break
                self.logger.error(f"WMI 监控发生 COM 错误: {e}")
            except Exception as e:
                # 捕获其他异常并记录
                self.logger.error(f"WMI 监控发生错误: {e}", exc_info=True)
                break # 发生意外错误时退出循环

    def _linux_monitor(self):
        """
        Linux 平台 USB 监控实现 (使用 pyudev)。
        """
        try:
            # 尝试导入 pyudev 和 psutil 库
            import pyudev
            import psutil
        except ImportError:
            self.logger.error("在 Linux 上运行需要 'pyudev' 和 'psutil' 库。请运行 'pip install pyudev psutil'。")
            notify_user("错误", "缺少 pyudev/psutil 库，无法在 Linux 上监控 USB。")
            return

        self.logger.info("启动 Linux pyudev 监控...")
        context = pyudev.Context() # 创建 udev 上下文
        monitor = pyudev.Monitor.from_netlink(context) # 从内核 netlink 创建监控器
        monitor.filter_by(subsystem='block') # 过滤只监听块设备事件

        self._observer = pyudev.MonitorObserver(monitor) # 创建监控观察者
        self._observer.start() # 启动观察者线程

        def device_event(action, device):
            """
            处理 udev 设备事件的回调函数。
            参数:
                action (str): 事件类型，如 'add', 'remove'。
                device (pyudev.Device): 触发事件的设备对象。
            """
            if not self._running: # 检查运行状态，允许优雅退出
                return

            # 检查设备是否是 USB 总线上的设备
            if 'ID_BUS' in device and device['ID_BUS'] == 'usb':
                dev_node = device.device_node # 设备节点，例如: /dev/sdb1
                # 尝试获取文件系统标签或设备型号作为设备名称，否则使用设备节点的基本名称
                device_name = device.get('ID_FS_LABEL') or device.get('ID_MODEL') or os.path.basename(dev_node)

                mount_path = None
                # 使用 psutil 遍历所有磁盘分区，查找设备的挂载点
                for part in psutil.disk_partitions():
                    if part.device == dev_node:
                        mount_path = part.mountpoint
                        break

                if action == 'add':
                    # 如果找到了挂载点，则使用挂载点；否则使用设备节点
                    self._on_device_added({'name': device_name, 'path': mount_path or dev_node})
                elif action == 'remove':
                    self._on_device_removed({'name': device_name, 'path': mount_path or dev_node})
            elif action == 'add' and 'DEVTYPE' in device and device['DEVTYPE'] == 'partition':
                 # 对于某些系统，ID_BUS 可能不直接用于分区，因此提供一个回退机制
                 # 检查是否是新的分区设备
                dev_node = device.device_node
                device_name = device.get('ID_FS_LABEL') or os.path.basename(dev_node)
                mount_path = None
                for part in psutil.disk_partitions():
                    if part.device == dev_node:
                        mount_path = part.mountpoint
                        break
                # 只有当找到挂载路径时，才认为它是一个可用的 USB 驱动器
                if mount_path:
                    self._on_device_added({'name': device_name, 'path': mount_path})

        self._observer.connect(device_event) # 将回调函数连接到观察者
        self.logger.info("pyudev 订阅成功。")

        # 保持此线程运行，直到 stop_monitoring 被调用
        while self._running:
            time.sleep(1)


    def start_monitoring(self):
        """
        启动 USB 监控。
        """
        self._running = True
        self.logger.info("开始 USB 监控...")
        if self._os_type == "Windows":
            self._windows_monitor()
        elif self._os_type == "Linux":
            self._linux_monitor()
        else:
            # 如果是其他不支持的操作系统，则记录错误并通知用户
            self.logger.error(f"不支持的操作系统: {self._os_type}")
            notify_user("错误", f"不支持当前操作系统: {self._os_type}")

    def stop_monitoring(self):
        """
        停止 USB 监控。
        """
        self.logger.info("停止 USB 监控...")
        self._running = False # 设置运行标志为 False
        if self._os_type == "Linux" and self._observer:
            self._observer.stop() # 停止 pyudev 观察者
            self._observer.join() # 等待观察者线程完全结束
        # Windows WMI 监控会在 _running 设为 False 后自然退出循环
        self.logger.info("USB 监控停止完成。")


# usb_monitor/scanner.py
import os
from usb_monitor.notifier import notify_user

def scan_drive(drive_path, logger, blacklisted_extensions, suspicious_files):
    """
    扫描指定驱动器路径是否存在 autorun.inf 或其他风险文件。
    参数:
        drive_path (str): 要扫描的驱动器或挂载点的路径。
        logger (logging.Logger): 日志记录器实例。
        blacklisted_extensions (list): 黑名单文件扩展名列表。
        suspicious_files (list): 可疑文件名列表。
    """
    logger.info(f"正在扫描驱动器: {drive_path}")
    found_risks = [] # 存储发现的风险文件信息

    # 检查 autorun.inf 文件
    autorun_path = os.path.join(drive_path, 'autorun.inf')
    if os.path.exists(autorun_path):
        found_risks.append(f"发现 autorun.inf 文件: {autorun_path}")
        logger.warning(f"风险警告: 发现 autorun.inf 文件在 {drive_path}")
        notify_user("风险文件警告", f"在 {drive_path} 发现 autorun.inf 文件。")

    # 扫描根目录下的可疑文件
    try:
        # 遍历驱动器根目录下的所有文件和子目录
        for item in os.listdir(drive_path):
            item_path = os.path.join(drive_path, item)
            # 只处理文件，跳过目录
            if os.path.isfile(item_path):
                # 检查文件名是否在可疑文件列表中 (不区分大小写)
                if item.lower() in [f.lower() for f in suspicious_files]:
                    found_risks.append(f"发现可疑文件: {item_path}")
                    logger.warning(f"风险警告: 发现可疑文件 '{item}' 在 {drive_path}")
                    notify_user("风险文件警告", f"在 {drive_path} 发现可疑文件: {item}")

                # 检查文件扩展名是否在黑名单中 (不区分大小写)
                _, ext = os.path.splitext(item) # 分离文件名和扩展名
                if ext.lower() in blacklisted_extensions:
                    found_risks.append(f"发现高风险文件 (黑名单扩展名): {item_path}")
                    logger.warning(f"风险警告: 发现黑名单扩展名文件 '{item}' 在 {drive_path}")
                    notify_user("高风险文件警告", f"在 {drive_path} 发现高风险文件 (黑名单扩展名): {item}")
    except PermissionError:
        # 如果没有权限访问驱动器，记录错误并通知用户
        logger.error(f"没有权限访问驱动器 {drive_path} 的文件。请以管理员权限运行。")
        notify_user("权限错误", f"没有权限访问驱动器 {drive_path} 的文件。")
    except Exception as e:
        # 捕获其他扫描过程中可能发生的异常
        logger.error(f"扫描驱动器 {drive_path} 时发生错误: {e}", exc_info=True)

    # 根据是否发现风险文件给出最终扫描结果的通知
    if not found_risks:
        logger.info(f"驱动器 {drive_path} 扫描完成，未发现明显风险文件。")
        notify_user("扫描完成", f"驱动器 {drive_path} 扫描完成，未发现明显风险。")
    else:
        logger.info(f"驱动器 {drive_path} 扫描完成，发现 {len(found_risks)} 处风险。")


# usb_monitor/logger.py
import logging
import os
import sys # 导入 sys 模块以使用 sys.stdout

def setup_logging(log_file='usb_monitor.log'):
    """
    配置日志记录。
    参数:
        log_file (str): 日志文件的路径。
    返回:
        logging.Logger: 配置好的日志记录器实例。
    """
    # 确保日志文件目录存在
    # 如果 log_file 是 "usb_monitor.log"，则 log_dir 会是空字符串，os.path.exists("") 为 True
    # 如果 log_file 是 "logs/usb_monitor.log"，则 log_dir 会是 "logs"，需要创建
    log_dir = os.path.dirname(log_file)
    if log_dir and not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # 配置基本的日志设置
    logging.basicConfig(
        level=logging.INFO, # 设置全局日志级别为 INFO，这意味着 INFO, WARNING, ERROR, CRITICAL 级别的日志都会被处理
        format='%(asctime)s - %(levelname)s - %(message)s', # 定义日志消息的格式
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'), # 将日志输出到指定的文件，并使用 UTF-8 编码
            logging.StreamHandler(sys.stdout) # 同时将日志输出到标准输出 (控制台)
        ]
    )
    # 禁用 plyer 内部的日志输出到控制台，避免其自身的调试信息干扰
    logging.getLogger('plyer').setLevel(logging.WARNING)
    # 禁用 pywin32 相关的 COM 和 WMI 模块的日志，减少不必要的输出
    logging.getLogger('com').setLevel(logging.WARNING)
    logging.getLogger('WMI').setLevel(logging.WARNING)

    # 获取一个特定名称的日志记录器实例，通常推荐使用 __name__
    logger = logging.getLogger(__name__)
    return logger


# usb_monitor/notifier.py
from plyer import notification
import sys
import tkinter as tk # 导入 tkinter
from tkinter import messagebox # 导入 messagebox

def notify_user(title, message, app_name="USB 监控器"):
    """
    通过桌面通知或弹窗提示用户。
    参数:
        title (str): 通知或弹窗的标题。
        message (str): 通知或弹窗的内容。
        app_name (str): 发送通知的应用程序名称。
    """
    try:
        # 尝试使用 plyer 发送桌面通知
        notification.notify(
            title=title,
            message=message,
            app_name=app_name,
            timeout=10 # 通知显示时间，单位秒
        )
    except Exception as e:
        # 如果 plyer 失败或未安装，尝试使用 tkinter.messagebox 作为备用方案
        print(f"无法发送桌面通知: {e}. 尝试使用备用弹窗 (如果可用)。")
        try:
            # 创建一个 Tkinter 根窗口实例，但不显示它
            root = tk.Tk()
            root.withdraw() # 隐藏主窗口，只显示消息框

            # 显示一个信息弹窗
            messagebox.showinfo(title, message)
            root.destroy() # 销毁 Tkinter 根窗口

        except ImportError:
            # 如果 tkinter 都未安装或无法导入
            print(f"警告: 无法使用 tkinter.messagebox，请检查是否在 GUI 环境下运行或安装 tkinter。")
            print(f"通知: {title} - {message}") # 仅在控制台打印消息
        except Exception as e_tk:
            # 捕获 tkinter 使用过程中可能发生的其他异常
            print(f"使用 tkinter.messagebox 失败: {e_tk}")
            print(f"通知: {title} - {message}") # 仅在控制台打印消息
# usb_monitor/config.py

# 黑名单文件扩展名列表
# 扫描器会查找这些扩展名的文件，并将其标记为高风险。
# 这些是常见的可执行文件、脚本文件和可能包含恶意代码的文件扩展名。
BLACKLISTED_EXTENSIONS = [
    '.exe',     # Windows 可执行文件
    '.bat',     # Windows 批处理文件
    '.cmd',     # Windows 命令脚本
    '.vbs',     # VBScript 脚本文件
    '.js',      # JavaScript 文件 (在某些上下文可执行)
    '.ps1',     # PowerShell 脚本文件
    '.scr',     # 屏幕保护程序文件 (可执行)
    '.lnk',     # Windows 快捷方式文件 (可被恶意利用执行命令)
    '.com',     # DOS 应用程序
    '.pif',     # 程序信息文件 (可执行)
    '.sh',      # Linux/Unix shell 脚本
    '.reg',     # 注册表文件 (可修改系统设置)
    '.dll'      # 动态链接库 (可被劫持或加载恶意代码)
]

# 可疑文件名列表
# 扫描器会查找这些精确文件名的文件，即使它们的扩展名不在黑名单中。
# 这些文件名通常被恶意软件用来伪装成系统文件或常见程序。
SUSPICIOUS_FILES = [
    'autorun.inf',      # 自动运行配置文件，尽管现代 Windows 已禁用其自动执行，但仍是感染迹象
    'svchost.exe',      # 恶意软件常用伪装名 (真实 svchost.exe 在 System32 目录下)
    'explorer.exe',     # 恶意软件常用伪装名
    'csrss.exe',        # 恶意软件常用伪装名
    'lsass.exe',        # 恶意软件常用伪装名
    'smss.exe',         # 恶意软件常用伪装名
    'winlogon.exe',     # 恶意软件常用伪装名
    'update.exe',       # 常见的恶意更新程序名
    'install.exe',      # 常见的恶意安装程序名
    'setup.exe',        # 常见的恶意安装程序名
    'README.txt.exe',   # 勒索软件常用伪装 (txt 扩展名在实际执行时被 .exe 覆盖)
    'HOWTO_DECRYPT.txt',# 勒索软件常用文件 (通常包含解密说明)
    # 可以根据需要添加更多可疑文件名，例如常见的勒索软件或恶意软件的文件名
]

# 其他未来可能用到的配置项 (目前未在代码中直接使用，但可以在此扩展)
# LOG_FILE_PATH = 'usb_monitor.log' # 日志文件路径
# NOTIFICATION_TIMEOUT_SECONDS = 10 # 通知显示时间（秒）
